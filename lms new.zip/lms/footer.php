<center>
		<footer>
		
		<p>Created by Heet Patel</p>
			<!-- <p>Programmed by: John Kevin Lorayna BSIS 4-A</p> -->
		</footer>
</center>

