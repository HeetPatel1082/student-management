				
								<div class="row-fluid">

						<div class="span12">
						
						</div>	
													
							</div>
							<div class="row-fluid">

						<!-- <div class="span4">
						<img class="index_logo" src="#">
						</div>	 -->
						<div class="span8">
						
								<div class="title">
							<h2>		
							<p class="SSGV">Parul University</p>
			                </h2>
							<h4>

							<p>Online Education Management System</p>
						
							</h4>		
						</div>
			
						</div>							
							</div>
				
				<div class="row-fluid">
-
						<div class="span12">
						<br>
								<div class="motto">
												<p>PARUL EXCELS:</p>
												<p>Excellence, Competence and Educational</p>
												<p>Leadership in Science and Technology</p>
								</div>		
						</div>		
				</div>