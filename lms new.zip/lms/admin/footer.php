<div class="pull-right">
		<footer>
           <p>Programmed by: Jay Patel (BCA-Big Data Analytics)</p>
        <footer>
</div>